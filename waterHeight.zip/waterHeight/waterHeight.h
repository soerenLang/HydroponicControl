#ifndef waterHeight_h
#define waterHeight_h

#include "Arduino.h"

class waterHeight
{
	public:
		waterHeight(int echoPin, int trigPin, int sensorHeight);
		float waterHeightMeasurement();
		int measureDelay;
		float measurementsAmount;
		int trigDelay;
		
	private:
		float timeToDistanceAir(long t);
		long measureDistance(int trigPin, int echoPin);
				
		int _echoPin;
		int _trigPin;
		int _sensorHeightmm = 169;
};

#endif