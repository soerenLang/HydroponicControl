#include "Arduino.h"
#include "waterHeight.h"

//class constructor
waterHeight :: waterHeight(int echoPin, int trigPin, int sensorHeight)
{
	//initializes which pins are going to be used
	_echoPin = echoPin;
	_trigPin = trigPin;
	
	//initializes the ports which the sensor uses
	pinMode(_echoPin, INPUT);
	pinMode(_trigPin, OUTPUT);
	
	//if the sensorHeight is set to 0, the height is predefined to be 169 mm
	if(sensorHeight == 0);
	else{
	_sensorHeightmm = sensorHeight;
	}
	measureDelay = 3;
	
	measurementsAmount = 4000;
	
	trigDelay = 10;
}

float waterHeight::timeToDistanceAir(long time)
{
	float toReturn;
	toReturn = time / 2;
	toReturn *= 0.34;
	return  toReturn;
}


//returns a value based on one measurement of the distance
long waterHeight :: measureDistance(int echopin, int trigpin)
{	
	long duration;
	//beings the measurments
	digitalWrite(trigpin, HIGH);
	// waits 10 microseconds to initialize the sensor
	delayMicroseconds(trigDelay);
	//sensor takes measurement when trigPin goes low
	digitalWrite(trigpin, LOW);

	duration = pulseIn(echopin, HIGH);

	long distance = timeToDistanceAir(duration);
	return distance;
}

//takes 4000 measurements and returns the average of these. 
float waterHeight :: waterHeightMeasurement ()
{
  float measurements = measurementsAmount;
  long sum = 0;
  for(int i = 0; i<measurements; i++)
  { 
    float toSum = measureDistance( _echoPin, _trigPin);
    sum += toSum;     
    delay(measureDelay);
  }
  
  sum/=measurements;
  
  return _sensorHeightmm-sum;
}
